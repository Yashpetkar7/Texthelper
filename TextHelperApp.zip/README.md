# Text Helper Streamlit App

Upload and edit `.txt` files easily.

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```
